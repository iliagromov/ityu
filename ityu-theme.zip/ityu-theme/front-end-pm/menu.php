<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div id="fep-content">
<?php do_action( 'fep_display_before_content' ); ?>
