<?php get_header(); ?>
<?php $scisco_header_img = get_theme_mod('scisco_subheader_cover_img', ''); ?>
<header id="scisco-header" data-img="<?php echo esc_url($scisco_header_img); ?>">
<?php get_template_part( 'templates/header/' . 'topnav', 'template'); ?>
    <div class="container-fluid">
        <div id="scisco-page-title">
            <h1>
            <?php
            if ( is_home() && ! is_front_page() ) {
                single_post_title();
            } else { 
                esc_html_e( 'Blog', 'scisco' ); 
            } 
            ?></h1>
            <?php 
            $scisco_subtitle = get_theme_mod('scisco_blog_subtitle');
            if (!empty($scisco_subtitle)) {
                echo '<p class="scisco-description">' . esc_html($scisco_subtitle) . '</p>';
            } ?> 
        </div>
    </div>
    <?php 
    $scisco_breadcrumb = get_theme_mod('scisco_disable_breadcrumb'); 
    if (empty($scisco_breadcrumb)) {
    ?>
    <div class="scisco-header-breadcrumb">
        <div class="container-fluid">
            <nav id="scisco-breadcrumb-menu" aria-label="breadcrumb">
                <?php scisco_bootstrap_breadcrumb(); ?>
            </nav>
        </div>
    </div>
    <?php } ?>
    <?php if (!empty($scisco_header_img)) { ?>
    <div id="scisco-header-overlay"></div>
    <?php } ?>
</header>

<main id="scisco-main-wrapper">
   <div>test</div>
</main>

<?php get_footer(); ?>