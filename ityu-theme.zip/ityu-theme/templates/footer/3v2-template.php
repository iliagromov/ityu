<div class="col-12 col-md-12 col-lg-6 mb-5 mb-md-5 mb-lg-0">
    <?php if ( is_active_sidebar( 'scisco_footer_widgets' ) ) {
        dynamic_sidebar( 'scisco_footer_widgets' );
    } ?>
</div>
<div class="col-12 col-md-6 col-lg-3 mb-5 mb-lg-0">
    <?php if ( is_active_sidebar( 'scisco_footer_2_widgets' ) ) {
        dynamic_sidebar( 'scisco_footer_2_widgets' );
    } ?>
</div>
<div class="col-12 col-md-6 col-lg-3">
    <?php if ( is_active_sidebar( 'scisco_footer_3_widgets' ) ) {
        dynamic_sidebar( 'scisco_footer_3_widgets' );
    } ?>
</div>
